/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author Lucas_Reinert
 */
public class Agua {
    private int idCond;
    private int idBloco;
    private int idApart;
    private int ano;
    private float Lei01;
    private float Lei02;
    private float Lei03;
    private float Lei04;
    private float Lei05;
    private float Lei06;
    private float Lei07;
    private float Lei08;
    private float Lei09;
    private float Lei10;
    private float Lei11;
    private float Lei12;    
    private Date data01;
    private Date data02;
    private Date data03;
    private Date data04;
    private Date data05;
    private Date data06;
    private Date data07;
    private Date data08;
    private Date data09;
    private Date data10;
    private Date data11;
    private Date data12;

    public Agua() {
    }

    public int getIdCond() {
        return idCond;
    }

    public void setIdCond(int idCond) {
        this.idCond = idCond;
    }

    public int getIdBloco() {
        return idBloco;
    }

    public void setIdBloco(int idBloco) {
        this.idBloco = idBloco;
    }

    public int getIdApart() {
        return idApart;
    }

    public void setIdApart(int idApart) {
        this.idApart = idApart;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public float getLei01() {
        return Lei01;
    }

    public void setLei01(float Lei01) {
        this.Lei01 = Lei01;
    }

    public float getLei02() {
        return Lei02;
    }

    public void setLei02(float Lei02) {
        this.Lei02 = Lei02;
    }

    public float getLei03() {
        return Lei03;
    }

    public void setLei03(float Lei03) {
        this.Lei03 = Lei03;
    }

    public float getLei04() {
        return Lei04;
    }

    public void setLei04(float Lei04) {
        this.Lei04 = Lei04;
    }

    public float getLei05() {
        return Lei05;
    }

    public void setLei05(float Lei05) {
        this.Lei05 = Lei05;
    }

    public float getLei06() {
        return Lei06;
    }

    public void setLei06(float Lei06) {
        this.Lei06 = Lei06;
    }

    public float getLei07() {
        return Lei07;
    }

    public void setLei07(float Lei07) {
        this.Lei07 = Lei07;
    }

    public float getLei08() {
        return Lei08;
    }

    public void setLei08(float Lei08) {
        this.Lei08 = Lei08;
    }

    public float getLei09() {
        return Lei09;
    }

    public void setLei09(float Lei09) {
        this.Lei09 = Lei09;
    }

    public float getLei10() {
        return Lei10;
    }

    public void setLei10(float Lei10) {
        this.Lei10 = Lei10;
    }

    public float getLei11() {
        return Lei11;
    }

    public void setLei11(float Lei11) {
        this.Lei11 = Lei11;
    }

    public float getLei12() {
        return Lei12;
    }

    public void setLei12(float Lei12) {
        this.Lei12 = Lei12;
    }

    public Date getData01() {
        return data01;
    }

    public void setData01(Date data01) {
        this.data01 = data01;
    }

    public Date getData02() {
        return data02;
    }

    public void setData02(Date data02) {
        this.data02 = data02;
    }

    public Date getData03() {
        return data03;
    }

    public void setData03(Date data03) {
        this.data03 = data03;
    }

    public Date getData04() {
        return data04;
    }

    public void setData04(Date data04) {
        this.data04 = data04;
    }

    public Date getData05() {
        return data05;
    }

    public void setData05(Date data05) {
        this.data05 = data05;
    }

    public Date getData06() {
        return data06;
    }

    public void setData06(Date data06) {
        this.data06 = data06;
    }

    public Date getData07() {
        return data07;
    }

    public void setData07(Date data07) {
        this.data07 = data07;
    }

    public Date getData08() {
        return data08;
    }

    public void setData08(Date data08) {
        this.data08 = data08;
    }

    public Date getData09() {
        return data09;
    }

    public void setData09(Date data09) {
        this.data09 = data09;
    }

    public Date getData10() {
        return data10;
    }

    public void setData10(Date data10) {
        this.data10 = data10;
    }

    public Date getData11() {
        return data11;
    }

    public void setData11(Date data11) {
        this.data11 = data11;
    }

    public Date getData12() {
        return data12;
    }

    public void setData12(Date data12) {
        this.data12 = data12;
    } 
}
